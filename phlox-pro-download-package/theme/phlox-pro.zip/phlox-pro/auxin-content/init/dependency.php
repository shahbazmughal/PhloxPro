<?php
/**
 * Dependency Credentials
 */
if( ! defined('AUXELS_REQUIRED_VERSION') ) define( 'AUXELS_REQUIRED_VERSION', '2.4.0' );
if( ! defined('AUXPFO_REQUIRED_VERSION') ) define( 'AUXPFO_REQUIRED_VERSION', '1.7.6' );
